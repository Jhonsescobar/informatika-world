# app/routers/student.py
# Router khusus untuk logika CBT Siswa

from fastapi import APIRouter, Request, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from jinja2 import Environment, FileSystemLoader
from pathlib import Path
from sqlalchemy.orm import Session
from datetime import datetime, timedelta, timezone

import logging
import random

from app.database import get_db
from app.utils.deps import require_student
from app.models.student import Student
from app.models.exam import Exam, ExamSession, ExamAnswer, RemedialRequest, ExamViolation, ExamEvent
from app.services.penilaian import (id_soal_sesi, total_poin_sesi, nilai_sesi, selesaikan_dari_log, TOLERANSI_KIRIM,
                                    kunci_pilihan, terapkan_kunci, KUNCI_JAWABAN, TOLERANSI_KUNCI)
from app.services.kesempatan import batas_hitung_pelanggaran
from app.services.rekap import rekap_kelas, status_ujian, tingkat_siswa, BATAS_REMEDIAL
from app.services.perkembangan import riwayat_siswa, bentuk_grafik, pesan_semangat
from app.services.esai import nilai_esai
import json
from app.models.material import Material
from fastapi.responses import JSONResponse
from sqlalchemy import func
from app.models.question import Question, QuestionOption
from app.models.academic import SchoolClass, Rombel, Enrollment, AcademicYear
from app.models.achievement import Achievement, StudentAchievement

try:
    from app.services.gamification import award_achievement
except ImportError:
    award_achievement = None

router = APIRouter(prefix="/student", tags=["Student"])
BASE_DIR = Path(__file__).resolve().parent.parent
templates_env = Environment(loader=FileSystemLoader(BASE_DIR / "templates"))
from app.services.teks import pasang as _pasang_filter
_pasang_filter(templates_env)   # filter |soal: teks soal aman + blok kode
log = logging.getLogger("informatika")

# --- PENGAMAN SESI UJIAN ---
# Toleransi keterlambatan kirim jawaban (jaringan lambat / tombol ditekan saat waktu habis)


def gagal(label: str, kembali: str = "/student/dashboard"):
    # Detail error hanya dicatat di konsol server; siswa melihat halaman umum
    log.exception(label)
    template = templates_env.get_template("error.html")
    return HTMLResponse(content=template.render(kembali=kembali), status_code=500)


def sesi_milik(db: Session, session_id: int, student_id: int):
    # Sesi ujian hanya boleh dibuka oleh siswa pemiliknya
    return db.query(ExamSession).filter(ExamSession.id == session_id, ExamSession.student_id == student_id).first()


MAKS_PELANGGARAN = 3     # keluar dari layar ujian sebanyak ini: jawaban dikirim otomatis


def persen_nilai(db: Session, sesi, exam):
    total = total_poin_sesi(db, sesi, exam)      # soal tiap siswa bisa berbeda
    if sesi.score is None or not total:
        return 0
    return round(sesi.score * 100 / total)


def sudah_lewat(sesi, toleransi=timedelta(0)):
    return datetime.now(timezone.utc) > sesi.expires_at + toleransi


# --- DASHBOARD ---
@router.get("/dashboard", response_class=HTMLResponse)
async def student_dashboard(request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        student_id = int(user.get("sub"))
        student = db.query(Student).filter(Student.id == student_id).first()
        tingkat = tingkat_siswa(db, student_id)
        # Hanya ujian untuk tingkat siswa ini (siswa tanpa rombel belum melihat ujian apa pun)
        exams = (db.query(Exam).filter(Exam.is_published == True, Exam.class_target == tingkat).all()
                 if tingkat else [])
        # Sesi terakhir yang sudah selesai per ujian: tampil "Selesai", bukan tombol Mulai
        selesai = {}
        for sesi in (db.query(ExamSession).filter(ExamSession.student_id == student_id, ExamSession.status != "active")
                     .order_by(ExamSession.id)):
            selesai[sesi.exam_id] = sesi
        remedial = {r.exam_id: r.status for r in db.query(RemedialRequest).filter(
            RemedialRequest.student_id == student_id, RemedialRequest.status.in_(["pending", "approved"]))}
        template = templates_env.get_template("student/dashboard.html")
        html_content = template.render(request=request, exams=exams, student_id=student_id, selesai=selesai,
                                       remedial=remedial, tingkat=tingkat, materi=materi_terbuka(db, tingkat),
                                       riwayat=riwayat_siswa(db, student_id),
                                       student_name=student.name if student else "", user=user, active_page="home")
        return HTMLResponse(content=html_content)
    except Exception:
        return gagal("Dashboard siswa", "/login")

# --- SINYAL ONLINE: halaman siswa mengirim "masih di sini" berkala (lihat static/js/iw-hadir.js) ---
@router.post("/ping")
async def ping_siswa(db: Session = Depends(get_db), user=Depends(require_student)):
    db.query(Student).filter(Student.id == int(user.get("sub"))).update(
        {Student.last_seen: datetime.now(timezone.utc)}, synchronize_session=False)
    db.commit()
    return {"ok": True}


# --- PERKEMBANGAN: grafik nilai ujian naik/turun ---
@router.get("/progress", response_class=HTMLResponse)
async def progress_page(request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        student_id = int(user.get("sub"))
        student = db.query(Student).filter(Student.id == student_id).first()
        riwayat = riwayat_siswa(db, student_id)
        terakhir = riwayat["titik"][-1] if riwayat["titik"] else None
        judul, kalimat = pesan_semangat(riwayat["tren"], riwayat["selisih"], bool(terakhir and terakhir["tuntas"]))
        template = templates_env.get_template("student/progress.html")
        return HTMLResponse(content=template.render(
            request=request, riwayat=riwayat, judul_tren=judul, kalimat_tren=kalimat, user=user, active_page="progress",
            g=bentuk_grafik(riwayat["titik"]) if riwayat["titik"] else None,
            student_name=student.name if student else ""))
    except Exception:
        return gagal("Perkembangan siswa")


# --- MULAI UJIAN ---
@router.post("/exam/start")
async def start_exam(request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        form = await request.form()
        exam_id = int(form.get("exam_id"))
        student_id = int(user.get("sub"))

        exam = db.query(Exam).filter(Exam.id == exam_id, Exam.is_published == True).first()
        if not exam or exam.class_target != tingkat_siswa(db, student_id):   # belum terbit / bukan tingkatnya
            return RedirectResponse(url="/student/dashboard", status_code=303)
        # Kunci baris siswa sampai selesai: dua klik "Mulai" bersamaan dulu bisa membuat 2 sesi (2 paket soal)
        db.query(Student.id).filter(Student.id == student_id).with_for_update().first()

        # Satu siswa satu kali mengerjakan: kalau sudah selesai/habis waktu, tampilkan hasilnya
        sesi_lama = db.query(ExamSession).filter(
            ExamSession.student_id == student_id,
            ExamSession.exam_id == exam_id,
        ).order_by(ExamSession.id.desc()).first()
        if sesi_lama:
            if sesi_lama.status == "active" and not sudah_lewat(sesi_lama, TOLERANSI_KIRIM):
                return RedirectResponse(url=f"/student/exam/take/{sesi_lama.id}", status_code=303)
            if sesi_lama.status == "active":
                selesaikan_dari_log(db, sesi_lama, exam)     # nilai dari jawaban yang sempat tersimpan
                db.commit()
            # Sudah pernah mengerjakan: hanya boleh lagi bila remedial disetujui guru (dipakai sekali)
            izin = db.query(RemedialRequest).filter(RemedialRequest.student_id == student_id,
                                                    RemedialRequest.exam_id == exam_id,
                                                    RemedialRequest.status == "approved").first()
            if not izin:
                return RedirectResponse(url=f"/student/exam/result/{sesi_lama.id}", status_code=303)
            izin.status = "used"

        now = datetime.now(timezone.utc)
        # Soal untuk siswa ini: diambil acak dari bank bila guru membatasi jumlahnya,
        # lalu urutannya dikunci di sesi supaya tetap sama walau halaman dimuat ulang
        semua_id = [q.id for q in db.query(Question.id).filter(Question.bank_id == exam.bank_id).order_by(Question.id)]
        if exam.question_count and exam.question_count < len(semua_id):
            dipilih = random.sample(semua_id, exam.question_count)
            if not exam.randomize_questions:
                dipilih.sort()
        else:
            dipilih = semua_id[:]
            if exam.randomize_questions:
                random.shuffle(dipilih)
        new_session = ExamSession(
            student_id=student_id,
            exam_id=exam_id,
            started_at=now,
            expires_at=now + timedelta(minutes=exam.duration_minutes),
            status="active",
            question_ids=",".join(map(str, dipilih)),
        )
        db.add(new_session)
        db.flush()
        db.add(ExamEvent(session_id=new_session.id, kind="mulai", detail=f"{len(dipilih)} soal"))
        db.commit()
        db.refresh(new_session)
        return RedirectResponse(url=f"/student/exam/take/{new_session.id}", status_code=303)
    except Exception:
        db.rollback()
        return gagal("Mulai ujian")

# --- HALAMAN UJIAN ---
@router.get("/exam/take/{session_id}", response_class=HTMLResponse)
async def take_exam(session_id: int, request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        session = sesi_milik(db, session_id, int(user.get("sub")))
        if not session:
            return RedirectResponse(url="/student/dashboard", status_code=303)
        if session.status != "active":
            return RedirectResponse(url=f"/student/exam/result/{session.id}", status_code=303)
        if sudah_lewat(session, TOLERANSI_KIRIM):
            selesaikan_dari_log(db, session)
            db.commit()
            return RedirectResponse(url=f"/student/exam/result/{session.id}", status_code=303)

        exam = db.query(Exam).filter(Exam.id == session.exam_id).first()
        ids = id_soal_sesi(db, session, exam)
        per_id = {q.id: q for q in db.query(Question).filter(Question.id.in_(ids))} if ids else {}
        # Jawaban terakhir yang tercatat di log: dipulihkan bila halaman dimuat ulang
        pilihan, esai = {}, {}
        for e in db.query(ExamEvent).filter(ExamEvent.session_id == session.id,
                                            ExamEvent.kind.in_(["pilih", "esai"])).order_by(ExamEvent.id):
            if e.kind == "pilih":
                pilihan[e.question_id] = e.option_id
            else:
                esai[e.question_id] = e.detail or ""
        kunci = kunci_pilihan(db, session)
        exam_data = []
        for qid in ids:
            q = per_id.get(qid)
            if not q:
                continue
            options = db.query(QuestionOption).filter(QuestionOption.question_id == q.id).order_by(QuestionOption.id).all()
            if exam.randomize_options:
                # urutan opsi tetap per siswa (acak tapi stabil saat dimuat ulang)
                random.Random(f"{session.id}-{q.id}").shuffle(options)
            k = kunci.get(q.id)
            exam_data.append({"question": q, "options": options,
                              "terpilih": k["opsi"] if k else pilihan.get(q.id), "teks": esai.get(q.id, ""),
                              "terkunci": bool(k) and k["sisa"] == 0, "sisa_kunci": k["sisa"] if k else None})
        template = templates_env.get_template("student/take_exam.html")
        html_content = template.render(
            request=request, exam=exam, exam_data=exam_data, session=session,
            expires_at=session.expires_at.isoformat(),
            student_name=db.query(Student.name).filter(Student.id == session.student_id).scalar() or "",
            sekarang=datetime.now().strftime("%d/%m/%Y %H:%M"), maks_pelanggaran=MAKS_PELANGGARAN,
            kunci_detik=int(KUNCI_JAWABAN.total_seconds())
        )
        return HTMLResponse(content=html_content)
    except Exception:
        return gagal("Halaman ujian")

# --- SUBMIT UJIAN ---
@router.post("/exam/submit/{session_id}")
async def submit_exam(session_id: int, request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        student_id = int(user.get("sub"))
        form = await request.form()
        # Kunci baris sesi: dua kiriman bersamaan (klik ganda / jaringan mengulang) dulu bisa tercatat dua kali
        session = (db.query(ExamSession).filter(ExamSession.id == session_id, ExamSession.student_id == student_id)
                   .with_for_update().first())
        if not session:
            return RedirectResponse(url="/student/dashboard", status_code=303)
        if session.status != "active":          # sudah dikirim / sudah habis: tidak bisa dikirim ulang
            return RedirectResponse(url=f"/student/exam/result/{session.id}", status_code=303)
        if sudah_lewat(session, TOLERANSI_KIRIM):
            # terlambat: isi form tidak dipakai, nilai dari jawaban yang tersimpan sebelum waktu habis
            selesaikan_dari_log(db, session)
            db.commit()
            return RedirectResponse(url=f"/student/exam/result/{session.id}", status_code=303)

        exam = db.query(Exam).filter(Exam.id == session.exam_id).first()
        session.submitted_at = datetime.now(timezone.utc)
        session.status = "completed"
        pilihan, esai = {}, {}
        for key, nilai in form.items():
            if key.startswith("essay_") and key[6:].isdigit():
                esai[int(key[6:])] = nilai if isinstance(nilai, str) else ""
            elif key.startswith("question_") and key[9:].isdigit() and str(nilai).isdigit():
                pilihan[int(key[9:])] = int(nilai)
        diabaikan = terapkan_kunci(db, session, pilihan)
        if diabaikan:
            db.add(ExamEvent(session_id=session.id, kind="kunci",
                             detail=f"{diabaikan} jawaban diganti setelah terkunci, diabaikan"))
        total_score, total_wrong = nilai_sesi(db, session, exam, pilihan, esai)
        db.add(ExamEvent(session_id=session.id, kind="kirim", detail="otomatis" if form.get("otomatis") else None))
        db.commit()
        # -------------------------------------------
        
        # --- ACHIEVEMENT LOGIC ---
        try:
            if award_achievement is not None:
                award_achievement(student_id=student_id, condition_type="FIRST_EXAM", db=db)
                if total_wrong == 0:
                    award_achievement(student_id=student_id, condition_type="PERFECT_SCORE", db=db)
        except Exception as ach_err:
            print(f"Warning: Achievement gagal - {ach_err}")
            
        return RedirectResponse(url=f"/student/exam/result/{session.id}", status_code=303)
    except Exception:
        db.rollback()
        return gagal("Kirim jawaban")

# --- HASIL UJIAN ---
@router.get("/exam/result/{session_id}", response_class=HTMLResponse)
async def exam_result(session_id: int, request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        student_id = int(user.get("sub"))
        session = sesi_milik(db, session_id, student_id)
        if not session:
            return RedirectResponse(url="/student/dashboard", status_code=303)
        exam = db.query(Exam).filter(Exam.id == session.exam_id).first()
        answers = db.query(ExamAnswer).filter(ExamAnswer.session_id == session_id).all()
        terakhir = (db.query(ExamSession.id).filter(ExamSession.student_id == student_id, ExamSession.exam_id == exam.id)
                    .order_by(ExamSession.id.desc()).first()[0] == session.id)
        permintaan = (db.query(RemedialRequest).filter(RemedialRequest.student_id == student_id,
                                                       RemedialRequest.exam_id == exam.id)
                      .order_by(RemedialRequest.id.desc()).first())
        persen = persen_nilai(db, session, exam)
        boleh_ajukan = (terakhir and session.status != "active" and persen < BATAS_REMEDIAL
                        and not (permintaan and permintaan.status in ("pending", "approved")))
        # Siswa hanya melihat "Tuntas" / "Belum tuntas", tanpa angka KKM
        tuntas = status_ujian(db, exam, student_id)["tuntas"]
        template = templates_env.get_template("student/exam_result.html")
        html_content = template.render(request=request, session=session, answers=answers, exam=exam, persen=persen,
                                       batas=BATAS_REMEDIAL, terakhir=terakhir, permintaan=permintaan,
                                       boleh_ajukan=boleh_ajukan, tuntas=tuntas)
        return HTMLResponse(content=html_content)
    except Exception:
        return gagal("Hasil ujian")

# --- REMEDIAL: siswa mengajukan, guru yang memutuskan ---
@router.post("/exam/remedial/{session_id}")
async def request_remedial(session_id: int, db: Session = Depends(get_db), user=Depends(require_student)):
    student_id = int(user.get("sub"))
    session = sesi_milik(db, session_id, student_id)
    if not session or session.status == "active":
        return RedirectResponse(url="/student/dashboard", status_code=303)
    exam = db.query(Exam).filter(Exam.id == session.exam_id).first()
    terakhir = (db.query(ExamSession.id).filter(ExamSession.student_id == student_id, ExamSession.exam_id == exam.id)
                .order_by(ExamSession.id.desc()).first()[0])
    masih_ada = db.query(RemedialRequest).filter(RemedialRequest.student_id == student_id, RemedialRequest.exam_id == exam.id,
                                                 RemedialRequest.status.in_(["pending", "approved"])).first()
    if terakhir == session.id and not masih_ada and persen_nilai(db, session, exam) < BATAS_REMEDIAL:
        db.add(RemedialRequest(student_id=student_id, exam_id=exam.id, session_id=session.id, status="pending"))
        db.commit()
    return RedirectResponse(url=f"/student/exam/result/{session.id}", status_code=303)

# --- LOG AKTIVITAS: soal dilihat, jawaban dipilih/diganti, esai diketik ---
MAKS_KEJADIAN_SESI = 3000
MAKS_ESAI_SESI = 400          # salinan teks esai di log (masing-masing <= 5000 huruf): maksimal ±2 MB per sesi
MAKS_PELANGGARAN_DICATAT = 300

@router.post("/exam/events/{session_id}")
async def log_events(session_id: int, request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    session = sesi_milik(db, session_id, int(user.get("sub")))
    if not session or session.status != "active" or sudah_lewat(session, TOLERANSI_KIRIM):
        return JSONResponse({"ok": False})       # jawaban lewat waktu tidak dicatat
    try:
        data = json.loads((await request.body())[:200_000] or b"[]")
    except ValueError:
        return JSONResponse({"ok": False})
    if not isinstance(data, list):
        return JSONResponse({"ok": False})
    exam = db.query(Exam).filter(Exam.id == session.exam_id).first()
    ids = set(id_soal_sesi(db, session, exam))
    opsi_soal = {o.id: o.question_id for o in db.query(QuestionOption).filter(QuestionOption.question_id.in_(list(ids)))}
    sisa = MAKS_KEJADIAN_SESI - db.query(func.count(ExamEvent.id)).filter(ExamEvent.session_id == session.id).scalar()
    sisa_esai = MAKS_ESAI_SESI - db.query(func.count(ExamEvent.id)).filter(ExamEvent.session_id == session.id,
                                                                            ExamEvent.kind == "esai").scalar()
    kini = datetime.now(timezone.utc)
    kunci = kunci_pilihan(db, session, kini)
    terkunci = set()
    simpan = 0
    for item in data[:100]:
        if simpan >= sisa or not isinstance(item, dict):
            break
        jenis, qid, oid = item.get("k"), item.get("q"), item.get("o")
        if jenis not in ("lihat", "pilih", "esai") or not isinstance(qid, int) or qid not in ids:
            continue
        if jenis == "pilih" and (not isinstance(oid, int) or opsi_soal.get(oid) != qid):
            continue
        if jenis == "pilih":
            k = kunci.get(qid)
            if k is None:                         # pilihan pertama: waktu kunci mulai berjalan
                kunci[qid] = {"batas": kini + KUNCI_JAWABAN}
            elif kini > k["batas"] + TOLERANSI_KUNCI:
                terkunci.add(qid)                 # sudah terkunci: perubahan tidak dicatat
                continue
        if jenis == "esai":
            if sisa_esai <= 0:
                continue
            sisa_esai -= 1
        detail = str(item.get("d") or "")[:5000] if jenis == "esai" else None
        db.add(ExamEvent(session_id=session.id, kind=jenis, question_id=qid,
                         option_id=oid if jenis == "pilih" else None, detail=detail))
        simpan += 1
    db.commit()
    return JSONResponse({"ok": True, "saved": simpan, "terkunci": sorted(terkunci)})

# --- ANTI-CHEAT: catat pelanggaran selama ujian ---
JENIS_PELANGGARAN = {"pindah_tab", "keluar_layar_penuh", "salin", "tempel", "klik_kanan", "screenshot", "cetak", "devtools"}

JEDA_SATU_KEJADIAN = 3  # detik

def hitung_keluar(waktu: list) -> int:
    """Catatan keluar layar yang berdekatan (< 3 detik dari awal kejadian) dihitung SATU kali keluar.
    Pindah aplikasi saat layar penuh mengirim 'keluar_layar_penuh' + 'pindah_tab' bersamaan."""
    jumlah, awal = 0, None
    for w in waktu:
        if w is None:
            continue
        if awal is None or (w - awal).total_seconds() >= JEDA_SATU_KEJADIAN:
            jumlah += 1
            awal = w
    return jumlah


@router.post("/exam/violation/{session_id}")
async def log_violation(session_id: int, request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    session = sesi_milik(db, session_id, int(user.get("sub")))
    if not session or session.status != "active":
        return JSONResponse({"count": 0, "limit": MAKS_PELANGGARAN, "active": False})
    form = await request.form()
    jenis = form.get("kind") if form.get("kind") in JENIS_PELANGGARAN else "lainnya"
    # batas catatan per sesi: kiriman bertubi-tubi tidak bisa membanjiri database
    if db.query(func.count(ExamViolation.id)).filter(ExamViolation.session_id == session.id).scalar() < MAKS_PELANGGARAN_DICATAT:
        db.add(ExamViolation(session_id=session.id, kind=jenis))
        db.commit()
    # Hanya pindah tab / keluar layar penuh yang dihitung menuju kirim otomatis
    q = db.query(ExamViolation.created_at).filter(
        ExamViolation.session_id == session.id, ExamViolation.kind.in_(["pindah_tab", "keluar_layar_penuh"]))
    mulai = batas_hitung_pelanggaran(db, session.id)          # setelah guru memberi kesempatan, hitungan mulai dari nol
    if mulai is not None:
        q = q.filter(ExamViolation.created_at > mulai)
    waktu = [w for (w,) in q.order_by(ExamViolation.created_at)]
    return JSONResponse({"count": hitung_keluar(waktu), "limit": MAKS_PELANGGARAN, "active": True})

# --- KISI-KISI MATERI ---
def materi_terbuka(db: Session, tingkat):
    sekarang = datetime.now(timezone.utc)
    if not tingkat:
        return []
    return (db.query(Material).filter(Material.is_published == True, Material.class_target == tingkat,
                                      (Material.open_at == None) | (Material.open_at <= sekarang),
                                      (Material.close_at == None) | (Material.close_at > sekarang))
            .order_by(Material.created_at.desc()).all())

@router.get("/materials", response_class=HTMLResponse)
async def materials_page(request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        materi = materi_terbuka(db, tingkat_siswa(db, int(user.get("sub"))))
        template = templates_env.get_template("student/materials.html")
        return HTMLResponse(content=template.render(request=request, materials=materi, active_page="materials"))
    except Exception:
        return gagal("Materi")

@router.get("/materials/{material_id}", response_class=HTMLResponse)
async def material_read(material_id: int, request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        student_id = int(user.get("sub"))
        materi = next((m for m in materi_terbuka(db, tingkat_siswa(db, student_id)) if m.id == material_id), None)
        if not materi:   # tertutup, kedaluwarsa, atau bukan untuk tingkatnya
            return RedirectResponse(url="/student/materials", status_code=303)
        student = db.query(Student).filter(Student.id == student_id).first()
        template = templates_env.get_template("student/material_read.html")
        return HTMLResponse(content=template.render(request=request, m=materi, student_name=student.name,
                                                    sekarang=datetime.now().strftime("%d/%m/%Y %H:%M"),
                                                    active_page="materials"))
    except Exception:
        return gagal("Baca materi", "/student/materials")

# --- LEADERBOARD ---
@router.get("/leaderboard", response_class=HTMLResponse)
async def leaderboard_page(request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        student_id = int(user.get("sub"))
        kelas = tingkat_siswa(db, student_id)
        template = templates_env.get_template("student/leaderboard.html")
        if not kelas:
            return HTMLResponse(content=template.render(request=request, user=user, rombel_name="–", class_name="–",
                                                        rombel_scores=[], angkatan_scores=[], active_page="leaderboard"))
        # Sumber nilai sama persis dengan rekap guru (nilai akhir tahun ajaran aktif)
        rekap = rekap_kelas(db, kelas)
        milik = next((r for r in rekap["baris"] if r["siswa"].id == student_id), None)
        angkatan = sorted(({"name": r["siswa"].name, "score": r["akhir"] or 0, "rombel_id": r["rombel_id"]}
                           for r in rekap["baris"]), key=lambda x: (-x["score"], x["name"].lower()))
        rombel_id = milik["rombel_id"] if milik else None
        html_content = template.render(
            request=request, user=user, rombel_name=milik["rombel"] if milik else "–", class_name=kelas,
            rombel_scores=[a for a in angkatan if a["rombel_id"] == rombel_id],
            angkatan_scores=angkatan, active_page="leaderboard"
        )
        return HTMLResponse(content=html_content)
    except Exception as e:
        return gagal("Peringkat")

# --- ACHIEVEMENTS ---
@router.get("/achievements", response_class=HTMLResponse)
async def achievements_page(request: Request, db: Session = Depends(get_db), user=Depends(require_student)):
    try:
        student_id = int(user.get("sub"))
        all_achievements = db.query(Achievement).all()
        my_awards = db.query(StudentAchievement).filter(StudentAchievement.student_id == student_id).all()
        my_award_ids = [aw.achievement_id for aw in my_awards]
        
        template = templates_env.get_template("student/achievements.html")
        html_content = template.render(
            request=request, user=user, all_achievements=all_achievements, 
            my_award_ids=my_award_ids, active_page="achievements"
        )
        return HTMLResponse(content=html_content)
    except Exception as e:
        return gagal("Lencana")