// iw-peri.js
// Peri kecil di beranda siswa: melayang pelan, bisa diseret (jari atau mouse), dan menaburkan kilau saat diketuk.
// Hanya dimuat di beranda. Tidak dipasang di halaman ujian. Menghormati "kurangi gerakan".
(function () {
  var kurangi = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var KUNCI = 'iw-peri-pos';
  var peri = document.createElement('div');
  peri.className = 'peri';
  peri.setAttribute('role', 'img');
  peri.setAttribute('aria-label', 'Peri kecil. Geser untuk memindahkan, ketuk untuk kilau.');
  peri.innerHTML =
    '<svg viewBox="0 0 64 64" width="64" height="64" aria-hidden="true">' +
    '<g class="peri-sayap"><ellipse class="s1" cx="20" cy="26" rx="14" ry="9" transform="rotate(-25 20 26)"/>' +
    '<ellipse class="s2" cx="44" cy="26" rx="14" ry="9" transform="rotate(25 44 26)"/>' +
    '<ellipse class="s3" cx="22" cy="36" rx="9" ry="6" transform="rotate(20 22 36)"/>' +
    '<ellipse class="s4" cx="42" cy="36" rx="9" ry="6" transform="rotate(-20 42 36)"/></g>' +
    '<circle class="badan" cx="32" cy="34" r="8"/><circle class="kepala" cx="32" cy="22" r="6"/>' +
    '<path class="bintang" d="M32 6l1.8 4.2 4.2 1.8-4.2 1.8L32 18l-1.8-4.2L26 12l4.2-1.8z"/></svg>';
  document.body.appendChild(peri);

  var W = 64, H = 64;
  function batas(x, y) {
    return [Math.max(4, Math.min(window.innerWidth - W - 4, x)), Math.max(4, Math.min(window.innerHeight - H - 4, y))];
  }
  function taruh(x, y) { var p = batas(x, y); peri.style.left = p[0] + 'px'; peri.style.top = p[1] + 'px'; return p; }
  var awal = null;
  try { awal = JSON.parse(sessionStorage.getItem(KUNCI)); } catch (e) {}
  if (awal) taruh(awal[0] * window.innerWidth, awal[1] * window.innerHeight);
  else taruh(window.innerWidth - 110, window.innerHeight * 0.28);
  window.addEventListener('resize', function () { taruh(peri.offsetLeft, peri.offsetTop); });

  function kilau() {
    if (kurangi) return;
    var r = peri.getBoundingClientRect();
    for (var i = 0; i < 9; i++) {
      var k = document.createElement('span');
      k.className = 'peri-kilau';
      var sudut = (Math.PI * 2 * i) / 9, jarak = 34 + Math.random() * 26;
      k.style.left = r.left + W / 2 + 'px';
      k.style.top = r.top + H / 2 + 'px';
      k.style.setProperty('--dx', Math.cos(sudut) * jarak + 'px');
      k.style.setProperty('--dy', Math.sin(sudut) * jarak + 'px');
      document.body.appendChild(k);
      setTimeout(function (el) { el.remove(); }.bind(null, k), 800);
    }
  }

  var seret = null, geser = 0;
  peri.addEventListener('pointerdown', function (e) {
    seret = { dx: e.clientX - peri.offsetLeft, dy: e.clientY - peri.offsetTop };
    geser = 0;
    peri.classList.add('is-dragged');
    peri.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  peri.addEventListener('pointermove', function (e) {
    if (!seret) return;
    geser += 1;
    taruh(e.clientX - seret.dx, e.clientY - seret.dy);
  });
  function lepas() {
    if (!seret) return;
    seret = null;
    peri.classList.remove('is-dragged');
    if (geser < 3) kilau();
    try { sessionStorage.setItem(KUNCI, JSON.stringify([peri.offsetLeft / window.innerWidth, peri.offsetTop / window.innerHeight])); } catch (e) {}
  }
  peri.addEventListener('pointerup', lepas);
  peri.addEventListener('pointercancel', lepas);
})();
