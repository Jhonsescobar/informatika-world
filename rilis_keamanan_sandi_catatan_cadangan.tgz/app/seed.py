# app/seed.py
# Script untuk mengisi database dengan data awal yang diperlukan oleh sistem

from sqlalchemy.orm import Session
from app.database import SessionLocal, engine
# Mengimpor pabrik sesi database dan mesin database

from app.models.achievement import Achievement
from app.models.user import User
from app.models.student import Student
from app.models.academic import AcademicYear, SchoolClass, Rombel
# Mengimpor model-model tabel yang akan kita isi

from app.utils.security import hash_password
# Mengimpor fungsi hash_password untuk mengamankan password guru

def seed_database():
    # Fungsi utama untuk menjalankan proses seeding
    
    db = SessionLocal()
    # Membuka koneksi ke database

    try:
        # 1. CEK APAKAH DATA SUDAH ADA (Agar tidak dobel jika script dijalankan 2x)
        existing_user = db.query(User).filter(User.email == "guru@informatika.world").first()
        # Cek apakah email guru sudah ada di database

        if existing_user:
            print("Data awal sudah ada. Tidak perlu di-seed lagi.")
            return
            # Jika sudah ada, hentikan proses

        # 2. MEMBUAT AKUN GURA ADMIN
        print("Membuat akun Guru...")
        hashed_pwd = hash_password("guru123")
        # Mengubah password 'guru123' menjadi teks hash Argon2 yang aman

        guru = User(
            email="guru@informatika.world",
            full_name="Guru Informatika",
            hashed_password=hashed_pwd,
            role="teacher",
            is_active=True,
            must_change_password=True,   # sandi bawaan: guru wajib menggantinya saat pertama masuk
        )
        db.add(guru)
        # Menambahkan data guru ke sesi database

        # 3. MEMBUAT TAHUN AJARAN
        print("Membuat Tahun Ajaran...")
        tahun_ajar = AcademicYear(year_name="2024/2025", is_active=1)
        db.add(tahun_ajar)

        # 4. MEMBUAT KELAS (VII, VIII, IX)
        print("Membuat Tingkat Kelas...")
        kelas_7 = SchoolClass(class_name="VII")
        kelas_8 = SchoolClass(class_name="VIII")
        kelas_9 = SchoolClass(class_name="IX")
        db.add_all([kelas_7, kelas_8, kelas_9])
        db.flush()  # isi kelas_7.id dst. sebelum dipakai untuk class_id rombel
        # Menambahkan 3 kelas sekaligus

                # 4b. BUAT 9 ROMBEL (VII.1 - IX.3)
        print("Membuat 9 Rombel...")
        rombels_data = [
            ("VII.1", kelas_7.id), ("VII.2", kelas_7.id), ("VII.3", kelas_7.id),
            ("VIII.1", kelas_8.id), ("VIII.2", kelas_8.id), ("VIII.3", kelas_8.id),
            ("IX.1", kelas_9.id), ("IX.2", kelas_9.id), ("IX.3", kelas_9.id),
        ]
        for r_name, c_id in rombels_data:
            existing = db.query(Rombel).filter(Rombel.rombel_name == r_name).first()
            if not existing:
                db.add(Rombel(rombel_name=r_name, class_id=c_id))
        db.commit()

        # 6. MEMBUAT SISWA CONTOH
        print("Membuat akun Siswa contoh...")
        pin_hash = hash_password("1234") # PIN 4 digit
        siswa_andi = Student(name="Andi Pratama", nipd="12345", pin_hash=pin_hash, is_active=True)
        db.add(siswa_andi)

                # 7. MEMBUAT ACHIEVEMENTS
        print("Membuat Achievements...")
        ach1 = Achievement(name="Computer Explorer", description="Menyelesaikan ujian pertama", icon="🚀", condition_type="FIRST_EXAM")
        ach2 = Achievement(name="Perfect Logic", description="Mendapat skor sempurna (100)", icon="💎", condition_type="PERFECT_SCORE")
        ach3 = Achievement(name="Digital Citizen", description="Terdaftar di kelas digital", icon="🌐", condition_type="ENROLLED")
        db.add_all([ach1, ach2, ach3])

        # 5. COMMIT (Simpan permanen ke PostgreSQL)
        db.commit()
        print("✅ Seeding berhasil! Akun guru dan struktur kelas telah dibuat.")

    except Exception as e:
        print(f"❌ Error saat seeding: {e}")
        db.rollback()
        # Jika ada error, batalkan semua perubahan yang belum tersimpan
    finally:
        db.close()
        # Pastikan koneksi database selalu ditutup

if __name__ == "__main__":
    # Jika file ini dijalankan langsung dari terminal (python -m app.seed)
    print("Memulai proses seeding database...")
    seed_database()